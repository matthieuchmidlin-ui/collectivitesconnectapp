# Déploiement TavauxConnect PWA — Guide rapide

## Option 1 — Netlify (recommandé, gratuit)

### Via drag & drop (le plus simple)
1. Créez un compte sur https://netlify.com
2. Allez sur https://app.netlify.com/drop
3. Glissez-déposez ce dossier entier (ou le ZIP)
4. Votre URL est prête en 30 secondes !
   Ex: `https://tavauxconnect-tavaux.netlify.app`

### Via CLI (pour mises à jour)
```bash
npm install -g netlify-cli
netlify login
netlify deploy --prod --dir .
```

### Domaine personnalisé (optionnel)
Dans Netlify → Site settings → Domain management
→ Ajoutez : `app.tavauxconnect.fr` ou `mairie-tavaux.app`

---

## Option 2 — Vercel (alternative)
1. https://vercel.com → New Project → Deploy
2. Glissez le dossier ou connectez GitHub
3. URL automatique : `tavauxconnect.vercel.app`

---

## Option 3 — GitHub Pages (gratuit)
```bash
git init
git add .
git commit -m "TavauxConnect PWA v1"
git remote add origin https://github.com/VOTRE_USER/tavauxconnect.git
git push -u origin main
```
Puis : GitHub → Settings → Pages → Source : main branch

---

## Contenu du dossier de déploiement

| Fichier | Rôle |
|---------|------|
| `index.html` | L'application complète |
| `manifest.json` | Config PWA (icône, nom, couleurs) |
| `sw.js` | Service Worker (cache offline) |
| `icon-192.png` | Icône app 192×192 |
| `icon-512.png` | Icône app 512×512 |
| `_redirects` | Routing Netlify (SPA) |
| `netlify.toml` | Headers sécurité + cache |

---

## Une fois déployé

### Sur Android
1. Ouvrez l'URL dans Chrome
2. Menu (⋮) → "Ajouter à l'écran d'accueil"
3. L'app apparaît comme une vraie app

### Sur iPhone
1. Ouvrez l'URL dans Safari
2. Bouton Partager → "Sur l'écran d'accueil"
3. L'app apparaît dans vos apps

### Partager avec la mairie
Envoyez simplement l'URL Netlify à la mairie de Tavaux.
Aucune installation requise — ça marche sur tout navigateur.

---

*PubCom Régies — contact@pubcom-regies.fr*
