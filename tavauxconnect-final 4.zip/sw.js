const CACHE = 'tavauxconnect-v3';
const ASSETS = ['/index.html'];

self.addEventListener('install', e => {
  e.waitUntil(caches.open(CACHE).then(c => c.addAll(ASSETS)));
  self.skipWaiting();
});

self.addEventListener('activate', e => {
  e.waitUntil(caches.keys().then(keys =>
    Promise.all(keys.filter(k => k !== CACHE).map(k => caches.delete(k)))
  ));
  self.clients.claim();
});

self.addEventListener('fetch', e => {
  const url = new URL(e.request.url);

  // Ne JAMAIS intercepter admin.html
  if (url.pathname.includes('admin')) return;

  // Ne pas cacher les APIs
  if (url.hostname.includes('supabase') ||
      url.hostname.includes('open-meteo') ||
      url.hostname.includes('nominatim') ||
      url.hostname.includes('emailjs') ||
      url.hostname.includes('googleapis') ||
      url.hostname.includes('cloudflare')) return;

  // Ne cacher que index.html
  if (url.pathname === '/' || url.pathname === '/index.html') {
    e.respondWith(
      caches.match('/index.html').then(c => c || fetch(e.request))
    );
  }
});
